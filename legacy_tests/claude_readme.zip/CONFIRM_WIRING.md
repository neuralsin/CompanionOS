# ✅ WIRING CONFIRMATION CHECKLIST

**BEFORE WE BUILD THE SOFTWARE, CONFIRM YOUR ACTUAL WIRING:**

---

## 🔧 **YOUR CURRENT WIRING (Based on User_Setup.h)**

### **TFT Display:**
```
✓ SCK  → D5 (GPIO14)
✓ MOSI → D7 (GPIO13)
✓ MISO → D6 (GPIO12)
✓ CS   → D2 (GPIO4)
✓ DC   → D1 (GPIO5)   ← Your file says GPIO5, NOT GPIO0!
✓ RST  → D0 (GPIO16)  ← Your file says GPIO16, NOT GPIO2!
✓ VCC  → 3.3V
✓ GND  → GND
```

---

## ❓ **WHAT I NEED YOU TO CONFIRM OR TELL ME:**

### **1. Touch Screen (XPT2046) - WHERE IS T_CS?**

I'm **guessing** it's on **D8 (GPIO15)** but YOU need to confirm:

```
T_CLK → D5 (GPIO14) - shared with TFT ✓
T_DIN → D7 (GPIO13) - shared with TFT ✓
T_DO  → D6 (GPIO12) - shared with TFT ✓
T_CS  → D? (GPIO?)  ← TELL ME!
```

**Please verify:** Is T_CS connected to **D8** or somewhere else?

---

### **2. Capacitive Touch Sensors - CLARIFY "D7" CONFLICT**

You said **"touch sensor i/o at D7"** but D7 is already used for TFT MOSI!

**This won't work!**

I've **assumed** you meant something different and assigned:
```
Left Touch Sensor  → D3 (GPIO0)  ← Confirm or tell me actual pin
Right Touch Sensor → D4 (GPIO2)  ← Confirm or tell me actual pin
```

**Please tell me:**
- Left capacitive sensor is actually on: `D?`
- Right capacitive sensor is actually on: `D?`
- Or did you only wire ONE sensor to D7 (need to move it)?

---

### **3. Microphone - MODEL AND PIN**

**What microphone module do you have?**
- [ ] MAX9814 (analog with auto-gain)
- [ ] MAX4466 (analog with manual pot)
- [ ] INMP441 (digital I2S)
- [ ] Other: ___________

**Where is it connected?**
- If analog: `A0` (yes/no?)
- If I2S: Which pins? (WS, SCK, SD)

---

### **4. HC-SR04 Distance Sensor**

You said "exclude for now" - should we:
- [ ] Plan pins but don't implement yet
- [ ] Skip completely for v1.0
- [ ] Add it now (tell me which pins)

If adding now, which pins:
- TRIG → `D?` (GPIO?)
- ECHO → `D?` (GPIO?) + voltage divider needed!

---

## 🎯 **QUICK ANSWER TEMPLATE**

**Copy and fill this:**

```
=== TOUCH SCREEN ===
T_CS connected to: D8 (GPIO15)  ← Confirm YES/NO, or tell actual pin

=== CAPACITIVE TOUCH SENSORS ===
How many sensors: 1 or 2?

If 1 sensor:
  Connected to: D? (GPIO?)

If 2 sensors:
  Left sensor:  D? (GPIO?)
  Right sensor: D? (GPIO?)

Sensor model: TTP223 / Other: _______
Active when touched: HIGH or LOW?

=== MICROPHONE ===
Model: MAX9814 / MAX4466 / INMP441 / Other: _______
Type: Analog / I2S
Pin(s): A0 / or (WS:__, SCK:__, SD:__)

=== HC-SR04 (Optional) ===
Include now: YES / NO / LATER

If YES:
  TRIG: D? (GPIO?)
  ECHO: D? (GPIO?)
  Voltage divider installed: YES / NO
```

---

## 🚨 **CRITICAL CONFLICTS TO RESOLVE**

### **Problem 1: "Touch sensor at D7"**
- D7 (GPIO13) is SPI MOSI for TFT
- Cannot use for capacitive sensor
- **Must move to different pin**

Suggested available pins:
- D3 (GPIO0) - boot pin but safe after boot
- D4 (GPIO2) - boot pin but safe after boot
- RX (GPIO3) - if not using Serial Monitor
- TX (GPIO1) - if not using Serial Monitor

### **Problem 2: Need to know T_CS pin**
- XPT2046 touch controller needs dedicated CS pin
- I assume D8 but need confirmation

---

## ✅ **ONCE YOU CONFIRM, I WILL:**

1. ✅ Finalize pin definitions
2. ✅ Update User_Setup.h (if needed)
3. ✅ Create complete Arduino code
4. ✅ Create Python controller
5. ✅ Build all pages (Eyes, Spotify, Notes, GitHub, Settings, etc.)
6. ✅ Implement all features
7. ✅ Package everything ready to upload

---

**Please fill out the template above so I can proceed!** 🎯
